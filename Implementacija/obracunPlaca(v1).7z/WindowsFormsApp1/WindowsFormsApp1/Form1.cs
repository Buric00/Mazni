﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            double brutoPlaca = Convert.ToDouble(textBox2.Text);
            double mir, zdrav, neto, doprinos, pripor;
            mir = 0.15 * brutoPlaca;
            zdrav = mir;
            doprinos = brutoPlaca * 0.022;
            pripor = (brutoPlaca - mir - zdrav) * 0.02;
            brutoIznos.Text = "Bruto iznos je: " + brutoPlaca + " kn";
            mirovinsko.Text = "Mirovinski dio iznosi: " + mir +" kn";
            zdravstveno.Text = "Zdravstveno iznosi: " + zdrav + " kn";
            dpr.Text = "Doprinosi iznose: " + doprinos + " kn";
            prirez.Text = "Prirez i porez iznose: " + pripor + " kn";
            netoIznos.Text = "Neto iznos plaće za isplatu radniku je: " + (brutoPlaca - mir - zdrav - doprinos - pripor) + " kn";

            

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
