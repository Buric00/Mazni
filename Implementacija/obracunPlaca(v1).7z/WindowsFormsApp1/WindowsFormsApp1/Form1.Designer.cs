﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.brutoIznos = new System.Windows.Forms.Label();
            this.netoIznos = new System.Windows.Forms.Label();
            this.zdravstveno = new System.Windows.Forms.Label();
            this.prirez = new System.Windows.Forms.Label();
            this.mirovinsko = new System.Windows.Forms.Label();
            this.dpr = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(28, 30);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(227, 125);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Radnik:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Bruto plaća:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(95, 35);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(114, 20);
            this.textBox1.TabIndex = 2;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(95, 67);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(114, 20);
            this.textBox2.TabIndex = 3;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(63, 180);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(159, 34);
            this.button1.TabIndex = 1;
            this.button1.Text = "Izračunaj neto iznos";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // brutoIznos
            // 
            this.brutoIznos.AutoSize = true;
            this.brutoIznos.Location = new System.Drawing.Point(380, 50);
            this.brutoIznos.Name = "brutoIznos";
            this.brutoIznos.Size = new System.Drawing.Size(0, 13);
            this.brutoIznos.TabIndex = 2;
            this.brutoIznos.Click += new System.EventHandler(this.label3_Click);
            // 
            // netoIznos
            // 
            this.netoIznos.AutoSize = true;
            this.netoIznos.Location = new System.Drawing.Point(380, 249);
            this.netoIznos.Name = "netoIznos";
            this.netoIznos.Size = new System.Drawing.Size(0, 13);
            this.netoIznos.TabIndex = 3;
            // 
            // zdravstveno
            // 
            this.zdravstveno.AutoSize = true;
            this.zdravstveno.Location = new System.Drawing.Point(380, 97);
            this.zdravstveno.Name = "zdravstveno";
            this.zdravstveno.Size = new System.Drawing.Size(0, 13);
            this.zdravstveno.TabIndex = 4;
            // 
            // prirez
            // 
            this.prirez.AutoSize = true;
            this.prirez.Location = new System.Drawing.Point(380, 142);
            this.prirez.Name = "prirez";
            this.prirez.Size = new System.Drawing.Size(0, 13);
            this.prirez.TabIndex = 5;
            // 
            // mirovinsko
            // 
            this.mirovinsko.AutoSize = true;
            this.mirovinsko.Location = new System.Drawing.Point(380, 72);
            this.mirovinsko.Name = "mirovinsko";
            this.mirovinsko.Size = new System.Drawing.Size(0, 13);
            this.mirovinsko.TabIndex = 6;
            // 
            // dpr
            // 
            this.dpr.AutoSize = true;
            this.dpr.Location = new System.Drawing.Point(370, 180);
            this.dpr.Name = "dpr";
            this.dpr.Size = new System.Drawing.Size(0, 13);
            this.dpr.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(753, 459);
            this.Controls.Add(this.dpr);
            this.Controls.Add(this.mirovinsko);
            this.Controls.Add(this.prirez);
            this.Controls.Add(this.zdravstveno);
            this.Controls.Add(this.netoIznos);
            this.Controls.Add(this.brutoIznos);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label brutoIznos;
        private System.Windows.Forms.Label netoIznos;
        private System.Windows.Forms.Label zdravstveno;
        private System.Windows.Forms.Label prirez;
        private System.Windows.Forms.Label mirovinsko;
        private System.Windows.Forms.Label dpr;
    }
}

