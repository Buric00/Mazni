﻿namespace Dobby
{
    partial class UnosNovogPoduzetnika
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
            this.UnosNovogPoduzetnika_Lable = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SifraPartnera = new System.Windows.Forms.TextBox();
            this.NazivPartnera_Label = new System.Windows.Forms.Label();
            this.NazivPartnera = new System.Windows.Forms.TextBox();
            this.Mjesto_Label = new System.Windows.Forms.Label();
            this.Mjesto = new System.Windows.Forms.TextBox();
            this.PostanskiBroj_Label = new System.Windows.Forms.Label();
            this.PostanskiBroj = new System.Windows.Forms.TextBox();
            this.Adresa_Label = new System.Windows.Forms.Label();
            this.Adresa = new System.Windows.Forms.TextBox();
            this.Drzava_Label = new System.Windows.Forms.Label();
            this.Drzava = new System.Windows.Forms.TextBox();
            this.EMail_Label = new System.Windows.Forms.Label();
            this.EMail = new System.Windows.Forms.TextBox();
            this.Oib_Label = new System.Windows.Forms.Label();
            this.OIB = new System.Windows.Forms.TextBox();
            this.PorezniOIB_Label = new System.Windows.Forms.Label();
            this.PorezniOIB = new System.Windows.Forms.TextBox();
            this.IBAN_Label = new System.Windows.Forms.Label();
            this.IBAN = new System.Windows.Forms.TextBox();
            this.TipPDVPartnera_Label = new System.Windows.Forms.Label();
            this.TipPDVPartnera = new System.Windows.Forms.ComboBox();
            this.BrojZaposlenih_Label = new System.Windows.Forms.Label();
            this.BrojZaposlenih = new System.Windows.Forms.TextBox();
            this.Aktiva_Label = new System.Windows.Forms.Label();
            this.Aktiva = new System.Windows.Forms.TextBox();
            this.Pasiva = new System.Windows.Forms.TextBox();
            this.Pasiva_Label = new System.Windows.Forms.Label();
            this.TipPoduzeca_Label = new System.Windows.Forms.Label();
            this.TipPoduzeca = new System.Windows.Forms.ComboBox();
            this.Djelatnost_Label = new System.Windows.Forms.Label();
            this.Biljeske_Label = new System.Windows.Forms.Label();
            this.Djelatnost = new System.Windows.Forms.TextBox();
            this.Biljeske = new System.Windows.Forms.TextBox();
            this.Unesi_Button = new System.Windows.Forms.Button();
            this.Reset_Button = new System.Windows.Forms.Button();
            this.Izlaz_Button = new System.Windows.Forms.Button();
            this.Name_Panel = new System.Windows.Forms.Panel();
            tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            tableLayoutPanel1.SuspendLayout();
            this.Name_Panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 10;
            tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            tableLayoutPanel1.Controls.Add(this.label1, 0, 3);
            tableLayoutPanel1.Controls.Add(this.SifraPartnera, 2, 3);
            tableLayoutPanel1.Controls.Add(this.NazivPartnera_Label, 3, 3);
            tableLayoutPanel1.Controls.Add(this.NazivPartnera, 5, 3);
            tableLayoutPanel1.Controls.Add(this.Mjesto_Label, 0, 4);
            tableLayoutPanel1.Controls.Add(this.Mjesto, 1, 4);
            tableLayoutPanel1.Controls.Add(this.PostanskiBroj_Label, 3, 4);
            tableLayoutPanel1.Controls.Add(this.PostanskiBroj, 5, 4);
            tableLayoutPanel1.Controls.Add(this.Adresa_Label, 6, 4);
            tableLayoutPanel1.Controls.Add(this.Adresa, 7, 4);
            tableLayoutPanel1.Controls.Add(this.Drzava_Label, 6, 5);
            tableLayoutPanel1.Controls.Add(this.Drzava, 7, 5);
            tableLayoutPanel1.Controls.Add(this.EMail_Label, 0, 7);
            tableLayoutPanel1.Controls.Add(this.EMail, 1, 7);
            tableLayoutPanel1.Controls.Add(this.Oib_Label, 4, 7);
            tableLayoutPanel1.Controls.Add(this.OIB, 5, 7);
            tableLayoutPanel1.Controls.Add(this.PorezniOIB_Label, 0, 8);
            tableLayoutPanel1.Controls.Add(this.PorezniOIB, 2, 8);
            tableLayoutPanel1.Controls.Add(this.IBAN_Label, 5, 8);
            tableLayoutPanel1.Controls.Add(this.IBAN, 6, 8);
            tableLayoutPanel1.Controls.Add(this.TipPDVPartnera_Label, 0, 10);
            tableLayoutPanel1.Controls.Add(this.TipPDVPartnera, 3, 10);
            tableLayoutPanel1.Controls.Add(this.BrojZaposlenih_Label, 0, 12);
            tableLayoutPanel1.Controls.Add(this.BrojZaposlenih, 2, 12);
            tableLayoutPanel1.Controls.Add(this.Aktiva_Label, 3, 12);
            tableLayoutPanel1.Controls.Add(this.Aktiva, 4, 12);
            tableLayoutPanel1.Controls.Add(this.Pasiva, 6, 12);
            tableLayoutPanel1.Controls.Add(this.Pasiva_Label, 5, 12);
            tableLayoutPanel1.Controls.Add(this.TipPoduzeca_Label, 0, 14);
            tableLayoutPanel1.Controls.Add(this.TipPoduzeca, 2, 14);
            tableLayoutPanel1.Controls.Add(this.Djelatnost_Label, 0, 16);
            tableLayoutPanel1.Controls.Add(this.Biljeske_Label, 0, 17);
            tableLayoutPanel1.Controls.Add(this.Djelatnost, 2, 16);
            tableLayoutPanel1.Controls.Add(this.Biljeske, 2, 17);
            tableLayoutPanel1.Controls.Add(this.Unesi_Button, 8, 14);
            tableLayoutPanel1.Controls.Add(this.Reset_Button, 8, 16);
            tableLayoutPanel1.Controls.Add(this.Izlaz_Button, 8, 18);
            tableLayoutPanel1.Controls.Add(this.Name_Panel, 0, 0);
            tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            tableLayoutPanel1.Font = new System.Drawing.Font("High Tower Text", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 20;
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            tableLayoutPanel1.Size = new System.Drawing.Size(881, 542);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // UnosNovogPoduzetnika_Lable
            // 
            this.UnosNovogPoduzetnika_Lable.Dock = System.Windows.Forms.DockStyle.Left;
            this.UnosNovogPoduzetnika_Lable.Font = new System.Drawing.Font("High Tower Text", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UnosNovogPoduzetnika_Lable.Location = new System.Drawing.Point(0, 0);
            this.UnosNovogPoduzetnika_Lable.Name = "UnosNovogPoduzetnika_Lable";
            this.UnosNovogPoduzetnika_Lable.Size = new System.Drawing.Size(261, 54);
            this.UnosNovogPoduzetnika_Lable.TabIndex = 0;
            this.UnosNovogPoduzetnika_Lable.Text = "Unos novog poduzetnika";
            this.UnosNovogPoduzetnika_Lable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(this.label1, 2);
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 27);
            this.label1.TabIndex = 1;
            this.label1.Text = "Šifra partnera";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SifraPartnera
            // 
            this.SifraPartnera.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SifraPartnera.Font = new System.Drawing.Font("High Tower Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SifraPartnera.Location = new System.Drawing.Point(179, 84);
            this.SifraPartnera.MaxLength = 5;
            this.SifraPartnera.Name = "SifraPartnera";
            this.SifraPartnera.ReadOnly = true;
            this.SifraPartnera.Size = new System.Drawing.Size(82, 26);
            this.SifraPartnera.TabIndex = 2;
            // 
            // NazivPartnera_Label
            // 
            this.NazivPartnera_Label.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(this.NazivPartnera_Label, 2);
            this.NazivPartnera_Label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NazivPartnera_Label.Location = new System.Drawing.Point(267, 81);
            this.NazivPartnera_Label.Name = "NazivPartnera_Label";
            this.NazivPartnera_Label.Size = new System.Drawing.Size(170, 27);
            this.NazivPartnera_Label.TabIndex = 3;
            this.NazivPartnera_Label.Text = "Naziv Partnera";
            this.NazivPartnera_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // NazivPartnera
            // 
            tableLayoutPanel1.SetColumnSpan(this.NazivPartnera, 5);
            this.NazivPartnera.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NazivPartnera.Font = new System.Drawing.Font("High Tower Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NazivPartnera.Location = new System.Drawing.Point(443, 84);
            this.NazivPartnera.MaxLength = 200;
            this.NazivPartnera.Name = "NazivPartnera";
            this.NazivPartnera.Size = new System.Drawing.Size(435, 26);
            this.NazivPartnera.TabIndex = 4;
            // 
            // Mjesto_Label
            // 
            this.Mjesto_Label.AutoSize = true;
            this.Mjesto_Label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Mjesto_Label.Location = new System.Drawing.Point(3, 108);
            this.Mjesto_Label.Name = "Mjesto_Label";
            this.Mjesto_Label.Size = new System.Drawing.Size(82, 27);
            this.Mjesto_Label.TabIndex = 5;
            this.Mjesto_Label.Text = "Mjesto";
            this.Mjesto_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Mjesto
            // 
            tableLayoutPanel1.SetColumnSpan(this.Mjesto, 2);
            this.Mjesto.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Mjesto.Font = new System.Drawing.Font("High Tower Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mjesto.Location = new System.Drawing.Point(91, 111);
            this.Mjesto.MaxLength = 100;
            this.Mjesto.Name = "Mjesto";
            this.Mjesto.Size = new System.Drawing.Size(170, 26);
            this.Mjesto.TabIndex = 6;
            // 
            // PostanskiBroj_Label
            // 
            this.PostanskiBroj_Label.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(this.PostanskiBroj_Label, 2);
            this.PostanskiBroj_Label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PostanskiBroj_Label.Location = new System.Drawing.Point(267, 108);
            this.PostanskiBroj_Label.Name = "PostanskiBroj_Label";
            this.PostanskiBroj_Label.Size = new System.Drawing.Size(170, 27);
            this.PostanskiBroj_Label.TabIndex = 7;
            this.PostanskiBroj_Label.Text = "Poštanski broj";
            this.PostanskiBroj_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PostanskiBroj
            // 
            this.PostanskiBroj.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PostanskiBroj.Font = new System.Drawing.Font("High Tower Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PostanskiBroj.Location = new System.Drawing.Point(443, 111);
            this.PostanskiBroj.MaxLength = 5;
            this.PostanskiBroj.Name = "PostanskiBroj";
            this.PostanskiBroj.Size = new System.Drawing.Size(82, 26);
            this.PostanskiBroj.TabIndex = 8;
            this.PostanskiBroj.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PostanskiBroj_KeyPress);
            // 
            // Adresa_Label
            // 
            this.Adresa_Label.AutoSize = true;
            this.Adresa_Label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Adresa_Label.Location = new System.Drawing.Point(531, 108);
            this.Adresa_Label.Name = "Adresa_Label";
            this.Adresa_Label.Size = new System.Drawing.Size(82, 27);
            this.Adresa_Label.TabIndex = 9;
            this.Adresa_Label.Text = "Adresa";
            // 
            // Adresa
            // 
            tableLayoutPanel1.SetColumnSpan(this.Adresa, 3);
            this.Adresa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Adresa.Font = new System.Drawing.Font("High Tower Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Adresa.Location = new System.Drawing.Point(619, 111);
            this.Adresa.MaxLength = 100;
            this.Adresa.Name = "Adresa";
            this.Adresa.Size = new System.Drawing.Size(259, 26);
            this.Adresa.TabIndex = 10;
            // 
            // Drzava_Label
            // 
            this.Drzava_Label.AutoSize = true;
            this.Drzava_Label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Drzava_Label.Location = new System.Drawing.Point(531, 135);
            this.Drzava_Label.Name = "Drzava_Label";
            this.Drzava_Label.Size = new System.Drawing.Size(82, 27);
            this.Drzava_Label.TabIndex = 11;
            this.Drzava_Label.Text = "Država";
            // 
            // Drzava
            // 
            tableLayoutPanel1.SetColumnSpan(this.Drzava, 3);
            this.Drzava.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Drzava.Font = new System.Drawing.Font("High Tower Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Drzava.Location = new System.Drawing.Point(619, 138);
            this.Drzava.MaxLength = 100;
            this.Drzava.Name = "Drzava";
            this.Drzava.Size = new System.Drawing.Size(259, 26);
            this.Drzava.TabIndex = 12;
            // 
            // EMail_Label
            // 
            this.EMail_Label.AutoSize = true;
            this.EMail_Label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.EMail_Label.Location = new System.Drawing.Point(3, 189);
            this.EMail_Label.Name = "EMail_Label";
            this.EMail_Label.Size = new System.Drawing.Size(82, 27);
            this.EMail_Label.TabIndex = 13;
            this.EMail_Label.Text = "E-mail";
            this.EMail_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EMail
            // 
            tableLayoutPanel1.SetColumnSpan(this.EMail, 3);
            this.EMail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.EMail.Font = new System.Drawing.Font("High Tower Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EMail.Location = new System.Drawing.Point(91, 192);
            this.EMail.MaxLength = 100;
            this.EMail.Name = "EMail";
            this.EMail.Size = new System.Drawing.Size(258, 26);
            this.EMail.TabIndex = 14;
            // 
            // Oib_Label
            // 
            this.Oib_Label.AutoSize = true;
            this.Oib_Label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Oib_Label.Location = new System.Drawing.Point(355, 189);
            this.Oib_Label.Name = "Oib_Label";
            this.Oib_Label.Size = new System.Drawing.Size(82, 27);
            this.Oib_Label.TabIndex = 15;
            this.Oib_Label.Text = "OIB";
            this.Oib_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // OIB
            // 
            tableLayoutPanel1.SetColumnSpan(this.OIB, 3);
            this.OIB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.OIB.Font = new System.Drawing.Font("High Tower Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OIB.Location = new System.Drawing.Point(443, 192);
            this.OIB.MaxLength = 11;
            this.OIB.Name = "OIB";
            this.OIB.Size = new System.Drawing.Size(258, 26);
            this.OIB.TabIndex = 16;
            this.OIB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.OIB_KeyPress);
            // 
            // PorezniOIB_Label
            // 
            this.PorezniOIB_Label.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(this.PorezniOIB_Label, 2);
            this.PorezniOIB_Label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PorezniOIB_Label.Location = new System.Drawing.Point(3, 216);
            this.PorezniOIB_Label.Name = "PorezniOIB_Label";
            this.PorezniOIB_Label.Size = new System.Drawing.Size(170, 27);
            this.PorezniOIB_Label.TabIndex = 17;
            this.PorezniOIB_Label.Text = "Porezni OIB";
            this.PorezniOIB_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PorezniOIB
            // 
            tableLayoutPanel1.SetColumnSpan(this.PorezniOIB, 3);
            this.PorezniOIB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PorezniOIB.Font = new System.Drawing.Font("High Tower Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PorezniOIB.Location = new System.Drawing.Point(179, 219);
            this.PorezniOIB.MaxLength = 30;
            this.PorezniOIB.Name = "PorezniOIB";
            this.PorezniOIB.Size = new System.Drawing.Size(258, 26);
            this.PorezniOIB.TabIndex = 18;
            // 
            // IBAN_Label
            // 
            this.IBAN_Label.AutoSize = true;
            this.IBAN_Label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.IBAN_Label.Location = new System.Drawing.Point(443, 216);
            this.IBAN_Label.Name = "IBAN_Label";
            this.IBAN_Label.Size = new System.Drawing.Size(82, 27);
            this.IBAN_Label.TabIndex = 19;
            this.IBAN_Label.Text = "IBAN";
            this.IBAN_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // IBAN
            // 
            tableLayoutPanel1.SetColumnSpan(this.IBAN, 4);
            this.IBAN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.IBAN.Font = new System.Drawing.Font("High Tower Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBAN.Location = new System.Drawing.Point(531, 219);
            this.IBAN.MaxLength = 50;
            this.IBAN.Name = "IBAN";
            this.IBAN.Size = new System.Drawing.Size(347, 26);
            this.IBAN.TabIndex = 20;
            // 
            // TipPDVPartnera_Label
            // 
            this.TipPDVPartnera_Label.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(this.TipPDVPartnera_Label, 3);
            this.TipPDVPartnera_Label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TipPDVPartnera_Label.Location = new System.Drawing.Point(3, 270);
            this.TipPDVPartnera_Label.Name = "TipPDVPartnera_Label";
            this.TipPDVPartnera_Label.Size = new System.Drawing.Size(258, 27);
            this.TipPDVPartnera_Label.TabIndex = 21;
            this.TipPDVPartnera_Label.Text = "Tip PDV partnera";
            this.TipPDVPartnera_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TipPDVPartnera
            // 
            tableLayoutPanel1.SetColumnSpan(this.TipPDVPartnera, 3);
            this.TipPDVPartnera.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TipPDVPartnera.Font = new System.Drawing.Font("High Tower Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TipPDVPartnera.FormattingEnabled = true;
            this.TipPDVPartnera.Location = new System.Drawing.Point(267, 273);
            this.TipPDVPartnera.Name = "TipPDVPartnera";
            this.TipPDVPartnera.Size = new System.Drawing.Size(258, 27);
            this.TipPDVPartnera.TabIndex = 22;
            // 
            // BrojZaposlenih_Label
            // 
            this.BrojZaposlenih_Label.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(this.BrojZaposlenih_Label, 2);
            this.BrojZaposlenih_Label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BrojZaposlenih_Label.Location = new System.Drawing.Point(3, 324);
            this.BrojZaposlenih_Label.Name = "BrojZaposlenih_Label";
            this.BrojZaposlenih_Label.Size = new System.Drawing.Size(170, 27);
            this.BrojZaposlenih_Label.TabIndex = 23;
            this.BrojZaposlenih_Label.Text = "Broj zaposlenih";
            this.BrojZaposlenih_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BrojZaposlenih
            // 
            this.BrojZaposlenih.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BrojZaposlenih.Font = new System.Drawing.Font("High Tower Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BrojZaposlenih.Location = new System.Drawing.Point(179, 327);
            this.BrojZaposlenih.MaxLength = 5;
            this.BrojZaposlenih.Name = "BrojZaposlenih";
            this.BrojZaposlenih.Size = new System.Drawing.Size(82, 26);
            this.BrojZaposlenih.TabIndex = 24;
            this.BrojZaposlenih.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.BrojZaposlenih_KeyPress);
            this.BrojZaposlenih.Leave += new System.EventHandler(this.BrojZaposlenih_Leave);
            // 
            // Aktiva_Label
            // 
            this.Aktiva_Label.AutoSize = true;
            this.Aktiva_Label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Aktiva_Label.Location = new System.Drawing.Point(267, 324);
            this.Aktiva_Label.Name = "Aktiva_Label";
            this.Aktiva_Label.Size = new System.Drawing.Size(82, 27);
            this.Aktiva_Label.TabIndex = 25;
            this.Aktiva_Label.Text = "Aktiva";
            this.Aktiva_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Aktiva
            // 
            this.Aktiva.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Aktiva.Font = new System.Drawing.Font("High Tower Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Aktiva.Location = new System.Drawing.Point(355, 327);
            this.Aktiva.MaxLength = 10;
            this.Aktiva.Name = "Aktiva";
            this.Aktiva.Size = new System.Drawing.Size(82, 26);
            this.Aktiva.TabIndex = 26;
            this.Aktiva.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Aktiva_KeyPress);
            this.Aktiva.Leave += new System.EventHandler(this.Aktiva_Leave);
            // 
            // Pasiva
            // 
            this.Pasiva.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Pasiva.Font = new System.Drawing.Font("High Tower Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pasiva.Location = new System.Drawing.Point(531, 327);
            this.Pasiva.MaxLength = 10;
            this.Pasiva.Name = "Pasiva";
            this.Pasiva.Size = new System.Drawing.Size(82, 26);
            this.Pasiva.TabIndex = 27;
            this.Pasiva.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Pasiva_KeyPress);
            // 
            // Pasiva_Label
            // 
            this.Pasiva_Label.AutoSize = true;
            this.Pasiva_Label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Pasiva_Label.Location = new System.Drawing.Point(443, 324);
            this.Pasiva_Label.Name = "Pasiva_Label";
            this.Pasiva_Label.Size = new System.Drawing.Size(82, 27);
            this.Pasiva_Label.TabIndex = 28;
            this.Pasiva_Label.Text = "Pasiva";
            this.Pasiva_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TipPoduzeca_Label
            // 
            this.TipPoduzeca_Label.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(this.TipPoduzeca_Label, 2);
            this.TipPoduzeca_Label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TipPoduzeca_Label.Location = new System.Drawing.Point(3, 378);
            this.TipPoduzeca_Label.Name = "TipPoduzeca_Label";
            this.TipPoduzeca_Label.Size = new System.Drawing.Size(170, 27);
            this.TipPoduzeca_Label.TabIndex = 29;
            this.TipPoduzeca_Label.Text = "Tip poduzeca";
            this.TipPoduzeca_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TipPoduzeca
            // 
            tableLayoutPanel1.SetColumnSpan(this.TipPoduzeca, 3);
            this.TipPoduzeca.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TipPoduzeca.Font = new System.Drawing.Font("High Tower Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TipPoduzeca.FormattingEnabled = true;
            this.TipPoduzeca.Location = new System.Drawing.Point(179, 381);
            this.TipPoduzeca.Name = "TipPoduzeca";
            this.TipPoduzeca.Size = new System.Drawing.Size(258, 27);
            this.TipPoduzeca.TabIndex = 30;
            // 
            // Djelatnost_Label
            // 
            this.Djelatnost_Label.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(this.Djelatnost_Label, 2);
            this.Djelatnost_Label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Djelatnost_Label.Location = new System.Drawing.Point(3, 432);
            this.Djelatnost_Label.Name = "Djelatnost_Label";
            this.Djelatnost_Label.Size = new System.Drawing.Size(170, 27);
            this.Djelatnost_Label.TabIndex = 31;
            this.Djelatnost_Label.Text = "Djelatnost";
            this.Djelatnost_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Biljeske_Label
            // 
            this.Biljeske_Label.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(this.Biljeske_Label, 2);
            this.Biljeske_Label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Biljeske_Label.Location = new System.Drawing.Point(3, 459);
            this.Biljeske_Label.Name = "Biljeske_Label";
            this.Biljeske_Label.Size = new System.Drawing.Size(170, 27);
            this.Biljeske_Label.TabIndex = 32;
            this.Biljeske_Label.Text = "Bilješke";
            this.Biljeske_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Djelatnost
            // 
            tableLayoutPanel1.SetColumnSpan(this.Djelatnost, 5);
            this.Djelatnost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Djelatnost.Font = new System.Drawing.Font("High Tower Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Djelatnost.Location = new System.Drawing.Point(179, 435);
            this.Djelatnost.MaxLength = 200;
            this.Djelatnost.Name = "Djelatnost";
            this.Djelatnost.Size = new System.Drawing.Size(434, 26);
            this.Djelatnost.TabIndex = 33;
            // 
            // Biljeske
            // 
            tableLayoutPanel1.SetColumnSpan(this.Biljeske, 5);
            this.Biljeske.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Biljeske.Font = new System.Drawing.Font("High Tower Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Biljeske.Location = new System.Drawing.Point(179, 462);
            this.Biljeske.Multiline = true;
            this.Biljeske.Name = "Biljeske";
            tableLayoutPanel1.SetRowSpan(this.Biljeske, 3);
            this.Biljeske.Size = new System.Drawing.Size(434, 77);
            this.Biljeske.TabIndex = 34;
            // 
            // Unesi_Button
            // 
            this.Unesi_Button.BackColor = System.Drawing.Color.SteelBlue;
            tableLayoutPanel1.SetColumnSpan(this.Unesi_Button, 2);
            this.Unesi_Button.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Unesi_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Unesi_Button.Location = new System.Drawing.Point(707, 381);
            this.Unesi_Button.Name = "Unesi_Button";
            tableLayoutPanel1.SetRowSpan(this.Unesi_Button, 2);
            this.Unesi_Button.Size = new System.Drawing.Size(171, 48);
            this.Unesi_Button.TabIndex = 35;
            this.Unesi_Button.Text = "Unesi";
            this.Unesi_Button.UseVisualStyleBackColor = false;
            this.Unesi_Button.Click += new System.EventHandler(this.Unesi_Button_Click);
            // 
            // Reset_Button
            // 
            this.Reset_Button.BackColor = System.Drawing.Color.Gold;
            tableLayoutPanel1.SetColumnSpan(this.Reset_Button, 2);
            this.Reset_Button.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Reset_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Reset_Button.Location = new System.Drawing.Point(707, 435);
            this.Reset_Button.Name = "Reset_Button";
            tableLayoutPanel1.SetRowSpan(this.Reset_Button, 2);
            this.Reset_Button.Size = new System.Drawing.Size(171, 48);
            this.Reset_Button.TabIndex = 36;
            this.Reset_Button.Text = "Reset";
            this.Reset_Button.UseVisualStyleBackColor = false;
            this.Reset_Button.Click += new System.EventHandler(this.Reset_Button_Click);
            // 
            // Izlaz_Button
            // 
            this.Izlaz_Button.BackColor = System.Drawing.Color.Firebrick;
            tableLayoutPanel1.SetColumnSpan(this.Izlaz_Button, 2);
            this.Izlaz_Button.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Izlaz_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Izlaz_Button.Location = new System.Drawing.Point(707, 489);
            this.Izlaz_Button.Name = "Izlaz_Button";
            tableLayoutPanel1.SetRowSpan(this.Izlaz_Button, 2);
            this.Izlaz_Button.Size = new System.Drawing.Size(171, 50);
            this.Izlaz_Button.TabIndex = 37;
            this.Izlaz_Button.Text = "Izlaz";
            this.Izlaz_Button.UseVisualStyleBackColor = false;
            this.Izlaz_Button.Click += new System.EventHandler(this.Izlaz_Button_Click);
            // 
            // Name_Panel
            // 
            this.Name_Panel.BackColor = System.Drawing.SystemColors.GrayText;
            tableLayoutPanel1.SetColumnSpan(this.Name_Panel, 10);
            this.Name_Panel.Controls.Add(this.UnosNovogPoduzetnika_Lable);
            this.Name_Panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Name_Panel.Location = new System.Drawing.Point(0, 0);
            this.Name_Panel.Margin = new System.Windows.Forms.Padding(0);
            this.Name_Panel.Name = "Name_Panel";
            tableLayoutPanel1.SetRowSpan(this.Name_Panel, 2);
            this.Name_Panel.Size = new System.Drawing.Size(881, 54);
            this.Name_Panel.TabIndex = 38;
            this.Name_Panel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Window_MouseDown);
            this.Name_Panel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Window_MouseMove);
            this.Name_Panel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Window_MouseUp);
            // 
            // UnosNovogPoduzetnika
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(881, 542);
            this.Controls.Add(tableLayoutPanel1);
            this.Name = "UnosNovogPoduzetnika";
            this.Text = "UnosNovogPoduzetnika";
            this.Load += new System.EventHandler(this.UnosNovogPoduzetnika_Load);
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            this.Name_Panel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label UnosNovogPoduzetnika_Lable;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox SifraPartnera;
        private System.Windows.Forms.Label NazivPartnera_Label;
        private System.Windows.Forms.TextBox NazivPartnera;
        private System.Windows.Forms.Label Mjesto_Label;
        private System.Windows.Forms.TextBox Mjesto;
        private System.Windows.Forms.Label PostanskiBroj_Label;
        private System.Windows.Forms.TextBox PostanskiBroj;
        private System.Windows.Forms.Label Adresa_Label;
        private System.Windows.Forms.TextBox Adresa;
        private System.Windows.Forms.Label Drzava_Label;
        private System.Windows.Forms.TextBox Drzava;
        private System.Windows.Forms.Label EMail_Label;
        private System.Windows.Forms.TextBox EMail;
        private System.Windows.Forms.Label Oib_Label;
        private System.Windows.Forms.TextBox OIB;
        private System.Windows.Forms.Label PorezniOIB_Label;
        private System.Windows.Forms.TextBox PorezniOIB;
        private System.Windows.Forms.Label IBAN_Label;
        private System.Windows.Forms.TextBox IBAN;
        private System.Windows.Forms.Label TipPDVPartnera_Label;
        private System.Windows.Forms.ComboBox TipPDVPartnera;
        private System.Windows.Forms.Label BrojZaposlenih_Label;
        private System.Windows.Forms.TextBox BrojZaposlenih;
        private System.Windows.Forms.Label Aktiva_Label;
        private System.Windows.Forms.TextBox Aktiva;
        private System.Windows.Forms.TextBox Pasiva;
        private System.Windows.Forms.Label Pasiva_Label;
        private System.Windows.Forms.Label TipPoduzeca_Label;
        private System.Windows.Forms.ComboBox TipPoduzeca;
        private System.Windows.Forms.Label Djelatnost_Label;
        private System.Windows.Forms.Label Biljeske_Label;
        private System.Windows.Forms.TextBox Djelatnost;
        private System.Windows.Forms.TextBox Biljeske;
        private System.Windows.Forms.Button Unesi_Button;
        private System.Windows.Forms.Button Reset_Button;
        private System.Windows.Forms.Button Izlaz_Button;
        private System.Windows.Forms.Panel Name_Panel;
    }
}