﻿namespace Dobby
{
    partial class PregledPartnera
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PregledPartnera_TableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.Name_Panel = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.Izlaz_Button = new System.Windows.Forms.Button();
            this.PregledPartnera_TableLayout.SuspendLayout();
            this.Name_Panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // PregledPartnera_TableLayout
            // 
            this.PregledPartnera_TableLayout.AutoScroll = true;
            this.PregledPartnera_TableLayout.ColumnCount = 20;
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.72935F));
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 0.7029877F));
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.2478F));
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 0.7029877F));
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 0.7029877F));
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 0.7029877F));
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.Controls.Add(this.Name_Panel, 0, 0);
            this.PregledPartnera_TableLayout.Controls.Add(this.Izlaz_Button, 18, 18);
            this.PregledPartnera_TableLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PregledPartnera_TableLayout.Font = new System.Drawing.Font("High Tower Text", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PregledPartnera_TableLayout.Location = new System.Drawing.Point(0, 0);
            this.PregledPartnera_TableLayout.Name = "PregledPartnera_TableLayout";
            this.PregledPartnera_TableLayout.RowCount = 20;
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.PregledPartnera_TableLayout.Size = new System.Drawing.Size(1138, 519);
            this.PregledPartnera_TableLayout.TabIndex = 0;
            // 
            // Name_Panel
            // 
            this.Name_Panel.BackColor = System.Drawing.SystemColors.GrayText;
            this.PregledPartnera_TableLayout.SetColumnSpan(this.Name_Panel, 20);
            this.Name_Panel.Controls.Add(this.label1);
            this.Name_Panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Name_Panel.Location = new System.Drawing.Point(0, 0);
            this.Name_Panel.Margin = new System.Windows.Forms.Padding(0);
            this.Name_Panel.Name = "Name_Panel";
            this.PregledPartnera_TableLayout.SetRowSpan(this.Name_Panel, 2);
            this.Name_Panel.Size = new System.Drawing.Size(1138, 50);
            this.Name_Panel.TabIndex = 0;
            this.Name_Panel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Window_MouseDown);
            this.Name_Panel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Window_MouseMove);
            this.Name_Panel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Window_MouseUp);
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Left;
            this.label1.Font = new System.Drawing.Font("High Tower Text", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 50);
            this.label1.TabIndex = 0;
            this.label1.Text = "Pregled Partnera";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Izlaz_Button
            // 
            this.Izlaz_Button.BackColor = System.Drawing.Color.Firebrick;
            this.PregledPartnera_TableLayout.SetColumnSpan(this.Izlaz_Button, 2);
            this.Izlaz_Button.Cursor = System.Windows.Forms.Cursors.Default;
            this.Izlaz_Button.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Izlaz_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Izlaz_Button.Font = new System.Drawing.Font("High Tower Text", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Izlaz_Button.Location = new System.Drawing.Point(1026, 453);
            this.Izlaz_Button.Name = "Izlaz_Button";
            this.PregledPartnera_TableLayout.SetRowSpan(this.Izlaz_Button, 2);
            this.Izlaz_Button.Size = new System.Drawing.Size(109, 63);
            this.Izlaz_Button.TabIndex = 1;
            this.Izlaz_Button.Text = "Izlaz";
            this.Izlaz_Button.UseVisualStyleBackColor = false;
            this.Izlaz_Button.Click += new System.EventHandler(this.Izlaz_Button_Click);
            // 
            // PregledPartnera
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1138, 519);
            this.Controls.Add(this.PregledPartnera_TableLayout);
            this.Name = "PregledPartnera";
            this.Text = "PregledPartnera";
            this.Load += new System.EventHandler(this.PregledPartnera_Load);
            this.PregledPartnera_TableLayout.ResumeLayout(false);
            this.Name_Panel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel PregledPartnera_TableLayout;
        private System.Windows.Forms.Panel Name_Panel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Izlaz_Button;
    }
}