﻿namespace Dobby
{
    partial class Prijava
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PrijavaLayout = new System.Windows.Forms.TableLayoutPanel();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.LozinkaLabel = new System.Windows.Forms.Label();
            this.KorisnickoImeLabel = new System.Windows.Forms.Label();
            this.UsernameTextBox = new System.Windows.Forms.TextBox();
            this.PrijavaButton = new System.Windows.Forms.Button();
            this.IzlazButton = new System.Windows.Forms.Button();
            this.PrijavaLayout.SuspendLayout();
            this.SuspendLayout();
            // 
            // PrijavaLayout
            // 
            this.PrijavaLayout.BackColor = System.Drawing.SystemColors.Window;
            this.PrijavaLayout.ColumnCount = 6;
            this.PrijavaLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.PrijavaLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.PrijavaLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.PrijavaLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.PrijavaLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.PrijavaLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.PrijavaLayout.Controls.Add(this.PasswordTextBox, 2, 3);
            this.PrijavaLayout.Controls.Add(this.LozinkaLabel, 0, 3);
            this.PrijavaLayout.Controls.Add(this.KorisnickoImeLabel, 0, 2);
            this.PrijavaLayout.Controls.Add(this.UsernameTextBox, 2, 2);
            this.PrijavaLayout.Controls.Add(this.PrijavaButton, 1, 5);
            this.PrijavaLayout.Controls.Add(this.IzlazButton, 3, 5);
            this.PrijavaLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PrijavaLayout.Font = new System.Drawing.Font("High Tower Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrijavaLayout.Location = new System.Drawing.Point(0, 0);
            this.PrijavaLayout.Name = "PrijavaLayout";
            this.PrijavaLayout.RowCount = 7;
            this.PrijavaLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.PrijavaLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.PrijavaLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.PrijavaLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.PrijavaLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.695652F));
            this.PrijavaLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.63768F));
            this.PrijavaLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.PrijavaLayout.Size = new System.Drawing.Size(384, 161);
            this.PrijavaLayout.TabIndex = 0;
            // 
            // PasswordTextBox
            // 
            this.PrijavaLayout.SetColumnSpan(this.PasswordTextBox, 3);
            this.PasswordTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PasswordTextBox.Location = new System.Drawing.Point(126, 75);
            this.PasswordTextBox.Margin = new System.Windows.Forms.Padding(0);
            this.PasswordTextBox.MaxLength = 20;
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.Size = new System.Drawing.Size(189, 26);
            this.PasswordTextBox.TabIndex = 3;
            this.PasswordTextBox.UseSystemPasswordChar = true;
            // 
            // LozinkaLabel
            // 
            this.LozinkaLabel.AutoSize = true;
            this.PrijavaLayout.SetColumnSpan(this.LozinkaLabel, 2);
            this.LozinkaLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LozinkaLabel.Location = new System.Drawing.Point(0, 75);
            this.LozinkaLabel.Margin = new System.Windows.Forms.Padding(0);
            this.LozinkaLabel.Name = "LozinkaLabel";
            this.LozinkaLabel.Size = new System.Drawing.Size(126, 25);
            this.LozinkaLabel.TabIndex = 1;
            this.LozinkaLabel.Text = "Lozinka:";
            this.LozinkaLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // KorisnickoImeLabel
            // 
            this.KorisnickoImeLabel.AutoSize = true;
            this.PrijavaLayout.SetColumnSpan(this.KorisnickoImeLabel, 2);
            this.KorisnickoImeLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.KorisnickoImeLabel.Location = new System.Drawing.Point(0, 50);
            this.KorisnickoImeLabel.Margin = new System.Windows.Forms.Padding(0);
            this.KorisnickoImeLabel.Name = "KorisnickoImeLabel";
            this.KorisnickoImeLabel.Size = new System.Drawing.Size(126, 25);
            this.KorisnickoImeLabel.TabIndex = 0;
            this.KorisnickoImeLabel.Text = "Korisničko ime:";
            this.KorisnickoImeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // UsernameTextBox
            // 
            this.PrijavaLayout.SetColumnSpan(this.UsernameTextBox, 3);
            this.UsernameTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.UsernameTextBox.Location = new System.Drawing.Point(126, 50);
            this.UsernameTextBox.Margin = new System.Windows.Forms.Padding(0);
            this.UsernameTextBox.MaxLength = 100;
            this.UsernameTextBox.Name = "UsernameTextBox";
            this.UsernameTextBox.Size = new System.Drawing.Size(189, 26);
            this.UsernameTextBox.TabIndex = 2;
            // 
            // PrijavaButton
            // 
            this.PrijavaButton.BackColor = System.Drawing.Color.LightSkyBlue;
            this.PrijavaLayout.SetColumnSpan(this.PrijavaButton, 2);
            this.PrijavaButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PrijavaButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PrijavaButton.Location = new System.Drawing.Point(66, 116);
            this.PrijavaButton.Name = "PrijavaButton";
            this.PrijavaButton.Size = new System.Drawing.Size(120, 31);
            this.PrijavaButton.TabIndex = 4;
            this.PrijavaButton.Text = "Prijava";
            this.PrijavaButton.UseVisualStyleBackColor = false;
            this.PrijavaButton.Click += new System.EventHandler(this.PrijavaButton_Click);
            // 
            // IzlazButton
            // 
            this.IzlazButton.BackColor = System.Drawing.Color.Firebrick;
            this.PrijavaLayout.SetColumnSpan(this.IzlazButton, 2);
            this.IzlazButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.IzlazButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.IzlazButton.Location = new System.Drawing.Point(192, 116);
            this.IzlazButton.Name = "IzlazButton";
            this.IzlazButton.Size = new System.Drawing.Size(120, 31);
            this.IzlazButton.TabIndex = 5;
            this.IzlazButton.Text = "Izlaz";
            this.IzlazButton.UseVisualStyleBackColor = false;
            this.IzlazButton.Click += new System.EventHandler(this.IzlazButton_Click);
            // 
            // Prijava
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 161);
            this.Controls.Add(this.PrijavaLayout);
            this.Name = "Prijava";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Prijava";
            this.Load += new System.EventHandler(this.Prijava_Load);
            this.PrijavaLayout.ResumeLayout(false);
            this.PrijavaLayout.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel PrijavaLayout;
        private System.Windows.Forms.Label KorisnickoImeLabel;
        private System.Windows.Forms.Label LozinkaLabel;
        private System.Windows.Forms.TextBox PasswordTextBox;
        private System.Windows.Forms.TextBox UsernameTextBox;
        private System.Windows.Forms.Button PrijavaButton;
        private System.Windows.Forms.Button IzlazButton;
    }
}