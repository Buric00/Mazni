﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dobby
{
    public partial class Sifrarnici : Form
    {
        Database m_database;

        public Sifrarnici()
        {
            InitializeComponent();
        }

        public void DohvatiPodatke(Database database)
        {
            m_database = database;
        }
    }
}
