﻿using System;
using System.Windows.Forms;

namespace Dobby
{
    public partial class ObracunPlaca : Form
    {
        Database m_database;

        public ObracunPlaca()
        {
            InitializeComponent();
        }

        private void ObracunPlaca_Load(object sender, EventArgs e)
        {

        }

        private void Izracunaj_Click(object sender, EventArgs e)
        {
            double brutoPlaca = Convert.ToDouble(brutoPlaca_TextBox.Text);
            double mir, zdrav, neto, doprinos, pripor;
            mir = 0.15 * brutoPlaca;
            zdrav = mir;
            doprinos = brutoPlaca * 0.022;
            pripor = (brutoPlaca - mir - zdrav) * 0.02;
            brutoIznos.Text = "Bruto iznos je: " + brutoPlaca + " kn";
            mirovinsko.Text = "Mirovinski dio iznosi: " + mir +" kn";
            zdravstveno.Text = "Zdravstveno iznosi: " + zdrav + " kn";
            dpr.Text = "Doprinosi iznose: " + doprinos + " kn";
            prirez.Text = "Prirez i porez iznose: " + pripor + " kn";
            netoIznos.Text = "Neto iznos plaće za isplatu radniku je: " + (brutoPlaca - mir - zdrav - doprinos - pripor) + " kn";
        }

        public void DohvatiPodatke(Database database)
        {
            m_database = database;
        }
    }
}
