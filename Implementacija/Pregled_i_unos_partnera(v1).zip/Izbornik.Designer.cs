﻿namespace Dobby
{
    partial class Window
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Window));
            this.MenuPanel = new System.Windows.Forms.Panel();
            this.Menu_Panel_Table = new System.Windows.Forms.TableLayoutPanel();
            this.IspisIzvjestaja_Button = new System.Windows.Forms.Button();
            this.PregledPoslovnihKnjiga_Button = new System.Windows.Forms.Button();
            this.ObracunPlaca_Button = new System.Windows.Forms.Button();
            this.Sifrarnici_Button = new System.Windows.Forms.Button();
            this.PDVObrasci_Button = new System.Windows.Forms.Button();
            this.PregledPartnera_Button = new System.Windows.Forms.Button();
            this.UnosNovogPoduzetnika_Button = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.Menu_Table = new System.Windows.Forms.TableLayoutPanel();
            this.PozdravnaPoruka = new System.Windows.Forms.Label();
            this.MenuPanel.SuspendLayout();
            this.Menu_Panel_Table.SuspendLayout();
            this.Menu_Table.SuspendLayout();
            this.SuspendLayout();
            // 
            // MenuPanel
            // 
            this.MenuPanel.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.MenuPanel.Controls.Add(this.Menu_Panel_Table);
            resources.ApplyResources(this.MenuPanel, "MenuPanel");
            this.MenuPanel.Name = "MenuPanel";
            this.Menu_Table.SetRowSpan(this.MenuPanel, 12);
            // 
            // Menu_Panel_Table
            // 
            resources.ApplyResources(this.Menu_Panel_Table, "Menu_Panel_Table");
            this.Menu_Panel_Table.Controls.Add(this.IspisIzvjestaja_Button, 0, 6);
            this.Menu_Panel_Table.Controls.Add(this.PregledPoslovnihKnjiga_Button, 0, 5);
            this.Menu_Panel_Table.Controls.Add(this.ObracunPlaca_Button, 0, 4);
            this.Menu_Panel_Table.Controls.Add(this.Sifrarnici_Button, 0, 3);
            this.Menu_Panel_Table.Controls.Add(this.PDVObrasci_Button, 0, 2);
            this.Menu_Panel_Table.Controls.Add(this.PregledPartnera_Button, 0, 1);
            this.Menu_Panel_Table.Controls.Add(this.UnosNovogPoduzetnika_Button, 0, 0);
            this.Menu_Panel_Table.Name = "Menu_Panel_Table";
            // 
            // IspisIzvjestaja_Button
            // 
            this.IspisIzvjestaja_Button.BackColor = System.Drawing.Color.LightSkyBlue;
            this.Menu_Panel_Table.SetColumnSpan(this.IspisIzvjestaja_Button, 4);
            resources.ApplyResources(this.IspisIzvjestaja_Button, "IspisIzvjestaja_Button");
            this.IspisIzvjestaja_Button.Name = "IspisIzvjestaja_Button";
            this.IspisIzvjestaja_Button.UseVisualStyleBackColor = false;
            this.IspisIzvjestaja_Button.Click += new System.EventHandler(this.IspisIzvjestaja_Button_Click);
            // 
            // PregledPoslovnihKnjiga_Button
            // 
            this.PregledPoslovnihKnjiga_Button.BackColor = System.Drawing.Color.LightSkyBlue;
            this.Menu_Panel_Table.SetColumnSpan(this.PregledPoslovnihKnjiga_Button, 4);
            resources.ApplyResources(this.PregledPoslovnihKnjiga_Button, "PregledPoslovnihKnjiga_Button");
            this.PregledPoslovnihKnjiga_Button.Name = "PregledPoslovnihKnjiga_Button";
            this.PregledPoslovnihKnjiga_Button.UseVisualStyleBackColor = false;
            this.PregledPoslovnihKnjiga_Button.Click += new System.EventHandler(this.PregledPoslovnihKnjiga_Button_Click);
            // 
            // ObracunPlaca_Button
            // 
            this.ObracunPlaca_Button.BackColor = System.Drawing.Color.LightSkyBlue;
            this.Menu_Panel_Table.SetColumnSpan(this.ObracunPlaca_Button, 4);
            resources.ApplyResources(this.ObracunPlaca_Button, "ObracunPlaca_Button");
            this.ObracunPlaca_Button.Name = "ObracunPlaca_Button";
            this.ObracunPlaca_Button.UseVisualStyleBackColor = false;
            this.ObracunPlaca_Button.Click += new System.EventHandler(this.ObracunPlaca_Button_Click);
            // 
            // Sifrarnici_Button
            // 
            this.Sifrarnici_Button.BackColor = System.Drawing.Color.LightSkyBlue;
            this.Menu_Panel_Table.SetColumnSpan(this.Sifrarnici_Button, 4);
            resources.ApplyResources(this.Sifrarnici_Button, "Sifrarnici_Button");
            this.Sifrarnici_Button.Name = "Sifrarnici_Button";
            this.Sifrarnici_Button.UseVisualStyleBackColor = false;
            this.Sifrarnici_Button.Click += new System.EventHandler(this.Sifrarnici_Button_Click);
            // 
            // PDVObrasci_Button
            // 
            this.PDVObrasci_Button.BackColor = System.Drawing.Color.LightSkyBlue;
            this.Menu_Panel_Table.SetColumnSpan(this.PDVObrasci_Button, 4);
            resources.ApplyResources(this.PDVObrasci_Button, "PDVObrasci_Button");
            this.PDVObrasci_Button.Name = "PDVObrasci_Button";
            this.PDVObrasci_Button.UseVisualStyleBackColor = false;
            this.PDVObrasci_Button.Click += new System.EventHandler(this.PDVObrasci_Button_Click);
            // 
            // PregledPartnera_Button
            // 
            this.PregledPartnera_Button.BackColor = System.Drawing.Color.LightSkyBlue;
            this.Menu_Panel_Table.SetColumnSpan(this.PregledPartnera_Button, 4);
            resources.ApplyResources(this.PregledPartnera_Button, "PregledPartnera_Button");
            this.PregledPartnera_Button.Name = "PregledPartnera_Button";
            this.PregledPartnera_Button.UseVisualStyleBackColor = false;
            this.PregledPartnera_Button.Click += new System.EventHandler(this.PregledPartnera_Button_Click);
            // 
            // UnosNovogPoduzetnika_Button
            // 
            this.UnosNovogPoduzetnika_Button.BackColor = System.Drawing.Color.LightSkyBlue;
            this.Menu_Panel_Table.SetColumnSpan(this.UnosNovogPoduzetnika_Button, 4);
            resources.ApplyResources(this.UnosNovogPoduzetnika_Button, "UnosNovogPoduzetnika_Button");
            this.UnosNovogPoduzetnika_Button.Name = "UnosNovogPoduzetnika_Button";
            this.UnosNovogPoduzetnika_Button.UseVisualStyleBackColor = false;
            this.UnosNovogPoduzetnika_Button.Click += new System.EventHandler(this.UnosNovogPoduzetnika_Button_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.BackColor = System.Drawing.Color.Firebrick;
            this.ExitButton.Cursor = System.Windows.Forms.Cursors.Arrow;
            resources.ApplyResources(this.ExitButton, "ExitButton");
            this.ExitButton.FlatAppearance.BorderColor = System.Drawing.SystemColors.WindowFrame;
            this.ExitButton.Name = "ExitButton";
            this.Menu_Table.SetRowSpan(this.ExitButton, 3);
            this.ExitButton.UseVisualStyleBackColor = false;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // Menu_Table
            // 
            resources.ApplyResources(this.Menu_Table, "Menu_Table");
            this.Menu_Table.Controls.Add(this.MenuPanel, 0, 0);
            this.Menu_Table.Controls.Add(this.ExitButton, 3, 9);
            this.Menu_Table.Controls.Add(this.PozdravnaPoruka, 2, 1);
            this.Menu_Table.Name = "Menu_Table";
            this.Menu_Table.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Window_MouseDown);
            this.Menu_Table.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Window_MouseMove);
            this.Menu_Table.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Window_MouseUp);
            // 
            // PozdravnaPoruka
            // 
            this.PozdravnaPoruka.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Menu_Table.SetColumnSpan(this.PozdravnaPoruka, 2);
            resources.ApplyResources(this.PozdravnaPoruka, "PozdravnaPoruka");
            this.PozdravnaPoruka.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.PozdravnaPoruka.Name = "PozdravnaPoruka";
            // 
            // Window
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ControlBox = false;
            this.Controls.Add(this.Menu_Table);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Window";
            this.Opacity = 0.99D;
            this.ShowIcon = false;
            this.Load += new System.EventHandler(this.Window_Load);
            this.MenuPanel.ResumeLayout(false);
            this.Menu_Panel_Table.ResumeLayout(false);
            this.Menu_Table.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel MenuPanel;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.TableLayoutPanel Menu_Table;
        private System.Windows.Forms.TableLayoutPanel Menu_Panel_Table;
        private System.Windows.Forms.Label PozdravnaPoruka;
        private System.Windows.Forms.Button IspisIzvjestaja_Button;
        private System.Windows.Forms.Button PregledPoslovnihKnjiga_Button;
        private System.Windows.Forms.Button ObracunPlaca_Button;
        private System.Windows.Forms.Button Sifrarnici_Button;
        private System.Windows.Forms.Button PDVObrasci_Button;
        private System.Windows.Forms.Button PregledPartnera_Button;
        private System.Windows.Forms.Button UnosNovogPoduzetnika_Button;
    }
}

