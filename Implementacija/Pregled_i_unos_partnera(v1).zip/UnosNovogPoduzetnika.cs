﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dobby
{
    public partial class UnosNovogPoduzetnika : Form
    {
        private Database m_database;
        private String sql;
        private bool mouseDown;
        private Point lastLocation;
        private bool m_pregled = false;
        private String m_nazivPartnera;

        private Dictionary<String, String> m_unos = new Dictionary<string, string>();
        private DataTable m_datatable = new DataTable();
        private String[] TipoviPDVPartnera = new String[]
        {
            "Domaci partner",
            "EU partner",
            "Inozemni partner"
        };

        private String[] TipoviPoduzeca = new String[]
        {
            "Mikro",
            "Mali",
            "Srednji",
            "Veliki"
        };

        public UnosNovogPoduzetnika()
        {
            InitializeComponent();
        }

        private void UnosNovogPoduzetnika_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.None;

            SifraPartnera.AutoSize = false;
            NazivPartnera.AutoSize = false;
            Mjesto.AutoSize = false;
            PostanskiBroj.AutoSize = false;
            Adresa.AutoSize = false;
            Drzava.AutoSize = false;
            EMail.AutoSize = false;
            OIB.AutoSize = false;
            PorezniOIB.AutoSize = false;
            IBAN.AutoSize = false;
            TipPDVPartnera.AutoSize = false;
            BrojZaposlenih.AutoSize = false;
            Aktiva.AutoSize = false;
            Pasiva.AutoSize = false;
            TipPoduzeca.AutoSize = false;
            Djelatnost.AutoSize = false;
            Biljeske.AutoSize = false;

            if (!m_pregled)
            {
                Initialize_ComboBox();

                sql = @"('SifraPartnera' VARCHAR(5) NOT NULL PRIMARY KEY, 'NazivPartnera' VARCHAR(100) NOT NULL, 'Mjesto' VARCHAR(50) NOT NULL, 'PostanskiBroj' VARHCAR(5) NOT NULL,
                    'Adresa' VARCHAR(50) NOT NULL, 'Drzava' VARCHAR(100) NOT NULL, 'EMail' VARCHAR(100) NOT NULL, 'OIB' VARCHAR(11) NOT NULL, 'PorezniOIB' VARCHAR(30) NOT NULL,
                    'IBAN' VARHCAR(50) NOT NULL, 'TipPDVPartnera' VARHCAR(1) NOT NULL, 'BrojZaposlenih' VARCHAR(5) NOT NULL, 'Aktiva' VARCHAR(10) NOT NULL, 'Pasiva' VARCHAR(10) NOT NULL,
                    'TipPoduzeca' VARCHAR(1) NOT NULL, 'Djelatnost' VARCHAR(200) NOT NULL, 'Biljeske' VARCHAR(1000));";

                m_database.Create_Table("Partneri", sql);

                sql = "SELECT MAX(SifraPartnera) FROM Partneri;";

                string izBaze = m_database.Get_Single_Data(sql);
                if(izBaze == "100")
                {
                    SifraPartnera.Text = "10000";
                }
                else
                {
                    int number = Convert.ToInt32(izBaze);
                    SifraPartnera.Text = (++number).ToString();
                }                
            }
            else
            {
                Reset_Button.Text = "Izbrisi";
                Unesi_Button.Text = "Izmjeni";
            }
        }

        public void DohvatiPodatke(Database database)
        {
            m_database = database;
        }

        public void Popuni(String nazivPartnera)
        {
            m_pregled = true;
            m_nazivPartnera = nazivPartnera;

            sql = "SELECT * FROM Partneri WHERE NazivPartnera = \"" + m_nazivPartnera + "\";";
            m_datatable = m_database.Get_Data(sql);
            Initialize_ComboBox();

            SifraPartnera.Text = m_datatable.Rows[0]["SifraPartnera"].ToString();
            NazivPartnera.Text = m_datatable.Rows[0]["NazivPartnera"].ToString();
            Mjesto.Text = m_datatable.Rows[0]["Mjesto"].ToString();
            PostanskiBroj.Text = m_datatable.Rows[0]["PostanskiBroj"].ToString();
            Adresa.Text = m_datatable.Rows[0]["Adresa"].ToString();
            Drzava.Text = m_datatable.Rows[0]["Drzava"].ToString();
            EMail.Text = m_datatable.Rows[0]["EMail"].ToString();
            OIB.Text = m_datatable.Rows[0]["OIB"].ToString();
            PorezniOIB.Text = m_datatable.Rows[0]["PorezniOIB"].ToString();
            IBAN.Text = m_datatable.Rows[0]["IBAN"].ToString();
            TipPDVPartnera.SelectedIndex = Convert.ToInt32(m_datatable.Rows[0]["TipPDVPartnera"]) - 1;
            BrojZaposlenih.Text = m_datatable.Rows[0]["BrojZaposlenih"].ToString();
            Aktiva.Text = m_datatable.Rows[0]["Aktiva"].ToString();
            Pasiva.Text = m_datatable.Rows[0]["Pasiva"].ToString();
            Djelatnost.Text = m_datatable.Rows[0]["Djelatnost"].ToString();
            TipPoduzeca.SelectedIndex = Convert.ToInt32(m_datatable.Rows[0]["TipPoduzeca"]) - 1;
            Biljeske.Text = m_datatable.Rows[0]["Biljeske"].ToString();
        }

        private void Initialize_ComboBox()
        {
            for (int i = 0; i < 3; i++)
            {
                TipPDVPartnera.Items.Add(TipoviPDVPartnera[i]);
            }

            TipPDVPartnera.SelectedIndex = 0;

            for (int i = 0; i < 4; i++)
            {
                TipPoduzeca.Items.Add(TipoviPoduzeca[i]);
            }

            TipPoduzeca.SelectedIndex = 0;
        }

        private void Unesi_Button_Click(object sender, EventArgs e)
        {
            if (Validacija())
            {
                m_unos.Add("SifraPartnera", SifraPartnera.Text);
                m_unos.Add("NazivPartnera", NazivPartnera.Text);
                m_unos.Add("Mjesto", Mjesto.Text);
                m_unos.Add("PostanskiBroj", PostanskiBroj.Text);
                m_unos.Add("Adresa", Adresa.Text);
                m_unos.Add("Drzava", Drzava.Text);
                m_unos.Add("EMail", EMail.Text);
                m_unos.Add("OIB", OIB.Text);
                m_unos.Add("PorezniOIB", PorezniOIB.Text);
                m_unos.Add("IBAN", IBAN.Text);
                m_unos.Add("TipPDVPartnera", (TipPDVPartnera.SelectedIndex + 1).ToString());
                m_unos.Add("BrojZaposlenih", BrojZaposlenih.Text);
                m_unos.Add("Aktiva", Aktiva.Text);
                m_unos.Add("Pasiva", Pasiva.Text);
                m_unos.Add("TipPoduzeca", (TipPoduzeca.SelectedIndex + 1).ToString());
                m_unos.Add("Djelatnost", Djelatnost.Text);
                m_unos.Add("Biljeske", Biljeske.Text);

                if(!m_pregled)
                {
                    if (m_database.Insert_Base("Partneri", m_unos))
                    {
                        MessageBox.Show("Uspješno uneseno u bazu!");
                        Resetiraj();
                    }
                    else
                    {
                        MessageBox.Show("Pogreška prilikom unosa, pokušajte ponovo!");
                    }
                }
                else
                {
                    if (m_database.Update_Dictionary("Partneri", m_unos, String.Format("Partneri.SifraPartnera = {0}", SifraPartnera.Text)))
                    {
                        MessageBox.Show("Uspješno izmjenjeno!");
                        Resetiraj();
                    }
                    else
                    {
                        MessageBox.Show("Pogreška pri izmjeni!");
                    }
                }
            }
        }

        private void BrojZaposlenih_Leave(object sender, EventArgs e)
        {
            if(Aktiva.Text.Length > 0)
            {
                Aktiva_Leave(sender, e);
            }
        }

        private void Aktiva_Leave(object sender, EventArgs e)
        {
            if (BrojZaposlenih.Text.Length > 0 && Aktiva.Text.Length > 0)
            {
                Decimal m_aktiva = Convert.ToDecimal(Aktiva.Text);
                int m_brojZaposlenih = Convert.ToInt32(BrojZaposlenih.Text);

                if (m_brojZaposlenih < 10)
                {
                    TipPoduzeca.SelectedIndex = ProvjeriAktivu(m_aktiva);
                }
                else if (m_brojZaposlenih < 50)
                {
                    TipPoduzeca.SelectedIndex = ProvjeriAktivu(m_aktiva);
                }
                else if (m_brojZaposlenih < 250)
                {
                    TipPoduzeca.SelectedIndex = ProvjeriAktivu(m_aktiva);
                }
                else
                {
                    TipPoduzeca.SelectedIndex = 3;
                }
            }
        }

        private int ProvjeriAktivu(Decimal m_aktiva)
        {
            if (m_aktiva < 2600000.0m)
            {
                return 0;
            }
            else if (m_aktiva < 30000000.0m)
            {
                return 1;
            }
            else if (m_aktiva < 150000000.0m)
            {
                return 2;
            }

            return 3;
        }

        private bool Validacija()
        {
            if(NazivPartnera.Text.Length < 1)
            {
                MessageBox.Show("Unesite ispravan naziv partnera!");
                return false;
            }
            if(Mjesto.Text.Length < 1)
            {
                MessageBox.Show("Unesite ispravno mjesto partnera!");
                return false;
            }
            if(PostanskiBroj.Text.Length < 5)
            {
                MessageBox.Show("Unesite ispravan poštanski broj partnera!");
                return false;
            }
            if(Adresa.Text.Length < 1)
            {
                MessageBox.Show("Unesite ispravnu adresu partnera!");
                return false;
            }
            if(Drzava.Text.Length < 1)
            {
                MessageBox.Show("Unesite ispravnu državu partnera!");
                return false;
            }
            if(EMail.Text.Length < 1)
            {
                MessageBox.Show("Unesite ispravan e-mail partnera!");
                return false;
            }
            if(OIB.Text.Length < 11)
            {
                MessageBox.Show("Unesite ispravan OIB partnera!");
                return false;
            }
            if(PorezniOIB.Text.Length < 18)
            {
                MessageBox.Show("Unesite ispravan porezni OIB partnera!");
                return false;
            }
            if(IBAN.Text.Length < 23)
            {
                MessageBox.Show("Unesite ispravan IBAN partnera!");
                return false;
            }
            if(BrojZaposlenih.Text.Length < 1)
            {
                MessageBox.Show("Unesite ispravan broj zaposlenih partnera!");
                return false;
            }
            if(Aktiva.Text.Length < 1)
            {
                MessageBox.Show("Unesite ispravnu aktivu partnera!");
                return false;
            }
            if(Pasiva.Text.Length < 1)
            {
                MessageBox.Show("Unesite ispravnu pasiva partnera!");
                return false;
            }
            if(Djelatnost.Text.Length < 1)
            {
                MessageBox.Show("Unesite ispravnu djelatnost partnera!");
                return false;
            }
            return true;
        }

        private void Reset_Button_Click(object sender, EventArgs e)
        {
            if(!m_pregled)
            {
                Resetiraj();
            }
            else
            {
                if(m_database.Delete("Partneri", String.Format("Partneri.SifraPartnera = {0}", SifraPartnera.Text)))
                {
                    MessageBox.Show("Uspješno obrisano!");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Brisanje nije uspjelo!");
                }
            }
        }

        private void Resetiraj()
        {
            sql = "SELECT MAX(SifraPartnera) FROM Partneri;";

            string izBaze = m_database.Get_Single_Data(sql);
            if (izBaze == "100")
            {
                SifraPartnera.Text = "10000";
            }
            else
            {
                int number = Convert.ToInt32(izBaze);
                SifraPartnera.Text = (++number).ToString();
            }
           
            NazivPartnera.Text = "";
            Mjesto.Text = "";
            PostanskiBroj.Text = "";
            Adresa.Text = "";
            Drzava.Text = "";
            EMail.Text = "";
            OIB.Text = "";
            PorezniOIB.Text = "";
            IBAN.Text = "";
            BrojZaposlenih.Text = "";
            Aktiva.Text = "";
            Pasiva.Text = "";
            Djelatnost.Text = "";
            TipPDVPartnera.SelectedIndex = 0;
            TipPoduzeca.SelectedIndex = 0;
           
            m_unos.Remove("SifraPartnera");
            m_unos.Remove("NazivPartnera");
            m_unos.Remove("Mjesto");
            m_unos.Remove("PostanskiBroj");
            m_unos.Remove("Adresa");
            m_unos.Remove("Drzava");
            m_unos.Remove("EMail");
            m_unos.Remove("OIB");
            m_unos.Remove("PorezniOIB");
            m_unos.Remove("IBAN");
            m_unos.Remove("TipPDVPartnera");
            m_unos.Remove("BrojZaposlenih");
            m_unos.Remove("Aktiva");
            m_unos.Remove("Pasiva");
            m_unos.Remove("Djelatnost");
            m_unos.Remove("TipPoduzeca");
            m_unos.Remove("Biljeske");

            if(m_pregled)
            {
                Popuni(m_nazivPartnera);
            }
        }

        private void SamoBrojevi(KeyPressEventArgs e)
        {
            // Ne dopusta unos bilo cega osim brojeva u OIB textbox
            e.Handled = !(char.IsDigit(e.KeyChar) || e.KeyChar == 8);
        }

        private void PostanskiBroj_KeyPress(object sender, KeyPressEventArgs e)
        {
            SamoBrojevi(e);
        }

        private void OIB_KeyPress(object sender, KeyPressEventArgs e)
        {
            SamoBrojevi(e);
        }

        private void BrojZaposlenih_KeyPress(object sender, KeyPressEventArgs e)
        {
            SamoBrojevi(e);
        }

        private void Aktiva_KeyPress(object sender, KeyPressEventArgs e)
        {
            SamoBrojevi(e);
        }

        private void Pasiva_KeyPress(object sender, KeyPressEventArgs e)
        {
            SamoBrojevi(e);
        }

        private void Izlaz_Button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Window_MouseDown(object sender, MouseEventArgs e)
        {
            // Ako stisnemo lijevi klik daje lokaciju pointera
            mouseDown = true;
            lastLocation = e.Location;
        }

        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            // Dok je stisnut lijevi klik i dok pomicemo racuna novu poziciju pointera
            if (mouseDown)
            {
                this.Location = new Point((this.Location.X - lastLocation.X) + e.X, (this.Location.Y - lastLocation.Y) + e.Y);

                // Updatea lokaciju prozora na ekranu
                this.Update();
            }
        }

        private void Window_MouseUp(object sender, MouseEventArgs e)
        {
            // Bez ovoga bi zauvijek micali prozor po ekranu
            mouseDown = false;
        }
    }
}
