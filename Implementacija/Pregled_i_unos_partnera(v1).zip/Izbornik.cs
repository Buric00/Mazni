﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Dobby
{
    public partial class Window : Form
    {
        Database m_database;
        DataTable                   m_datatable         = new DataTable();
        
        private bool                opened = false;
        private String              sql;
        private bool                mouseDown;
        private Point               lastLocation;
          

        public Window()
        {
            // Inicijalizira sve komponente na prozoru
            InitializeComponent();
        }

        private void Window_Load(object sender, EventArgs e)
        {
            // Uklanja border, dakle nema one trake sa minimize, maximize i exit
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            if (!opened)
            {
                // Gumb za exit
                Close();
            }
            else
            {
                ProzorVecOtvoren();
            }
        }

        private void Window_MouseDown(object sender, MouseEventArgs e)
        {
            // Ako stisnemo lijevi klik daje lokaciju pointera
            mouseDown = true;
            lastLocation = e.Location;
        }

        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            // Dok je stisnut lijevi klik i dok pomicemo racuna novu poziciju pointera
            if (mouseDown)
            {
                this.Location = new Point((this.Location.X - lastLocation.X) + e.X, (this.Location.Y - lastLocation.Y) + e.Y);

                // Updatea lokaciju prozora na ekranu
                this.Update();
            }
        }

        private void Window_MouseUp(object sender, MouseEventArgs e)
        {
            // Bez ovoga bi zauvijek micali prozor po ekranu
            mouseDown = false;
        }

        private void UnosNovogPoduzetnika_Button_Click(object sender, EventArgs e)
        {
            if(!opened)
            {
                UnosNovogPoduzetnika m_unosNovogPoduzetnika = new UnosNovogPoduzetnika();
                m_unosNovogPoduzetnika.FormClosed += new FormClosedEventHandler(Window_Closed);
                opened = true;
                m_unosNovogPoduzetnika.DohvatiPodatke(m_database);
                m_unosNovogPoduzetnika.Show();
            }
            else
            {
                ProzorVecOtvoren();
            }
        }

        private void PregledPartnera_Button_Click(object sender, EventArgs e)
        {
            if(!opened)
            {
                PregledPartnera m_pregledPartnera = new PregledPartnera();
                m_pregledPartnera.FormClosed += new FormClosedEventHandler(Window_Closed);
                opened = true;
                m_pregledPartnera.DohvatiPodatke(m_database);
                m_pregledPartnera.Show();
            }
        }

        private void PDVObrasci_Button_Click(object sender, EventArgs e)
        {
            if (!opened)
            {
                PDVObrazac m_pdvObrazac = new PDVObrazac();
                m_pdvObrazac.FormClosed += new FormClosedEventHandler(Window_Closed);
                opened = true;
                m_pdvObrazac.DohvatiPodatke(m_database);
                m_pdvObrazac.Show();
            }
            else
            {
                ProzorVecOtvoren();
            }
        }

        private void Sifrarnici_Button_Click(object sender, EventArgs e)
        {
            if (!opened)
            {
                Sifrarnici m_sifrarnici = new Sifrarnici();
                m_sifrarnici.FormClosed += new FormClosedEventHandler(Window_Closed);
                opened = true;
                m_sifrarnici.DohvatiPodatke(m_database);
                m_sifrarnici.Show();
            }
            else
            {
                ProzorVecOtvoren();
            }
        }

        private void ObracunPlaca_Button_Click(object sender, EventArgs e)
        {
            if (!opened)
            {
                ObracunPlaca m_obracunPlaca = new ObracunPlaca();
                m_obracunPlaca.FormClosed += new FormClosedEventHandler(Window_Closed);
                opened = true;
                m_obracunPlaca.DohvatiPodatke(m_database);
                m_obracunPlaca.Show();
            }
            else
            {
                ProzorVecOtvoren();
            }
        }

        private void PregledPoslovnihKnjiga_Button_Click(object sender, EventArgs e)
        {

        }

        private void IspisIzvjestaja_Button_Click(object sender, EventArgs e)
        {

        }

        public void DohvatiPodatke (Database database, String ime)
        {
            m_database = database;
            PozdravnaPoruka.Text = "Pozdrav " + ime + "!";
        }

        private void ProzorVecOtvoren ()
        {
            MessageBox.Show("Prozor je otvoren. Prvo zatvorite drugi prozor!");
        }

        private void Window_Closed(object sender, FormClosedEventArgs e)
        {
            opened = false;
        }

        /* buttoni kako namjestiti

         private void Dodaj_Novog_Click(object sender, EventArgs e)
         {
             if(!opened)
             {
                 opened = true;
                 Companies_Insert m_companies_Insert = new Companies_Insert();
                 m_companies_Insert.FormClosed += new FormClosedEventHandler(companies_Insert_Closed);

                 // Otvara novi prozor, Companies_Insert.cs
                 m_companies_Insert.Show();
             }
         }

         private void companies_Insert_Closed(object sender, FormClosedEventArgs e)
         {
             // Kad se zatvori update-a listu firmi
             Update_List();

             opened = false;
         }

         private void Update_List()
         {
             // Sql za odabiranje svih firmi iz baze, poziva metodu iz database.cs i popunjava datatable
             sql = "SELECT * FROM Partneri ORDER BY name;";
             m_datatable = m_database.Get_Data(sql);

             // Listboxu kao source podataka daje datatable, ono sto vidimo = name, a kao vrijednost dobijemo ID
             Firme_Lista.DataSource = m_datatable;
             Firme_Lista.DisplayMember = "name";
             Firme_Lista.ValueMember = "ID";
         }*/
    }
}
