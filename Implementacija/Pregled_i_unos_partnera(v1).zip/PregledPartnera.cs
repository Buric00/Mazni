﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dobby
{
    public partial class PregledPartnera : Form
    {
        Database    m_database;
        DataTable   m_dataTable;
        String      sql;
        bool        opened = false;
        bool        mouseDown = false;
        Point       lastLocation;

        public PregledPartnera()
        {
            InitializeComponent();
        }

        private void PregledPartnera_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;

            FillLabels();
        }

        public void DohvatiPodatke(Database database)
        {
            m_database = database;
        }
        
        private void Label_Click(object sender, EventArgs e)
        {
            if (!opened)
            {
                Label my_label = sender as Label;

                UnosNovogPoduzetnika m_pregled = new UnosNovogPoduzetnika();
                m_pregled.FormClosed += new FormClosedEventHandler(Window_Closed);
                opened = true;
                m_pregled.DohvatiPodatke(m_database);
                m_pregled.Popuni(my_label.Text);
                m_pregled.Show();
            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            opened = false;
            for (int i = 1 + m_dataTable.Rows.Count * 2; i > 2; i--)
            {
                PregledPartnera_TableLayout.Controls.RemoveAt(i);
            }

            FillLabels();
        }

        private void FillLabels()
        {
            sql = "SELECT * FROM Partneri ORDER BY NazivPartnera;";
            m_dataTable = m_database.Get_Data(sql);

            for (int i = 0; i < m_dataTable.Rows.Count; i++)
            {
                PregledPartnera_TableLayout.Controls.Add
                     (
                         new Label()
                         {
                             Text = m_dataTable.Rows[i]["NazivPartnera"].ToString(),
                             Dock = DockStyle.Fill,
                         },
                        1,
                        4 + i
                    );

                if (i == 0)
                {
                    var temp_NazivPartnera = PregledPartnera_TableLayout.Controls[i + 2];
                    temp_NazivPartnera.Click += new EventHandler(Label_Click);
                }
                else
                {
                    var temp_NazivPartnera = PregledPartnera_TableLayout.Controls[(i + 1) * 2];
                    temp_NazivPartnera.Click += new EventHandler(Label_Click);
                }

                PregledPartnera_TableLayout.Controls.Add
                    (
                        new Label()
                        {
                            Text = m_dataTable.Rows[i]["OIB"].ToString(),
                            Dock = DockStyle.Fill
                        },
                        3,
                        4 + i
                    );
            }
        }

        private void Izlaz_Button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Window_MouseDown(object sender, MouseEventArgs e)
        {
            // Ako stisnemo lijevi klik daje lokaciju pointera
            mouseDown = true;
            lastLocation = e.Location;
        }

        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            // Dok je stisnut lijevi klik i dok pomicemo racuna novu poziciju pointera
            if (mouseDown)
            {
                this.Location = new Point((this.Location.X - lastLocation.X) + e.X, (this.Location.Y - lastLocation.Y) + e.Y);

                // Updatea lokaciju prozora na ekranu
                this.Update();
            }
        }

        private void Window_MouseUp(object sender, MouseEventArgs e)
        {
            // Bez ovoga bi zauvijek micali prozor po ekranu
            mouseDown = false;
        }
    }
}
