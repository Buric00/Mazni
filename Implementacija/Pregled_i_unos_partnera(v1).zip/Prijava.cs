﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dobby
{
    public partial class Prijava : Form
    {
        Database m_database = new Database();
        String sql;
        String ime;
        Dictionary<String, String> korisnik = new Dictionary<string, string>();

        public Prijava()
        {
            InitializeComponent();
        }

        private void Prijava_Load(object sender, EventArgs e)
        {
            // Uklanja border, dakle nema one trake sa minimize, maximize i exit
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;

            m_database.Initialize();
            m_database.Connect();

            // Inicijalizacija tablica
            m_database.Create_Table("Korisnici", "(ID VARCHAR(3) NOT NULL PRIMARY KEY, username VARCHAR(100) NOT NULL, password VARCHAR(20) NOT NULL);");

            korisnik.Add("ID", "000");
            korisnik.Add("username", "admin");
            korisnik.Add("password", "admin");

            m_database.Insert_Base("Korisnici", korisnik);
        }

        private void PrijavaButton_Click(object sender, EventArgs e)
        {
            sql = "SELECT username FROM Korisnici WHERE username = \"" + UsernameTextBox.Text + "\" AND password = \"" + PasswordTextBox.Text + "\";";
            ime = m_database.Get_Single_Data(sql);

            if (ime == UsernameTextBox.Text)
            {
                Window m_window = new Window();
                m_window.FormClosed += new FormClosedEventHandler(Window_Closed);

                m_window.DohvatiPodatke(m_database, ime);
                Hide();

                m_window.Show();
            }
            else
            {
                MessageBox.Show("Unesite ispravno korisničko ime ili lozinku!");
            }
        }

        private void Window_Closed (object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void IzlazButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}