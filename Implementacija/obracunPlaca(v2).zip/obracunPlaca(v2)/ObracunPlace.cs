﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace ObracunPlace
{
    public partial class ObracunPlace : Form
    {
        public ObracunPlace()
        {
            InitializeComponent();
        }

        

        private void izracun_button_Click(object sender, EventArgs e)
        {
            String dopusteno = "^[0-9]+(,[0-9]+)*$";

            if (radnik_unos.Text.Length == 0)
            {
                MessageBox.Show("Unesite ime radnika!");
            }
            else if(!Regex.IsMatch(radnik_unos.Text, "^[a-zA-Z ]+$")){
                MessageBox.Show("Unesite ispravno ime i prezime radnika! Unos smije sadržavati samo slova i razmake!");
            }
            else if (brutoIznos_unos.Text.Length == 0)
            {
                MessageBox.Show("Unesite bruto iznos!");
            }
            else if (!Regex.IsMatch(brutoIznos_unos.Text, dopusteno))
            {
                MessageBox.Show("Niste unijeli valjan broj! Umjesto decimalne točke uvijek koristite zarez!");
            }

            else
            {
                double brutoIznos;
                brutoIznos = Convert.ToDouble(brutoIznos_unos.Text);
                bruto_labela.Text = "" + brutoIznos;
                mirovinsko_labela.Text = "" + (0.15 * brutoIznos);
                zdravstveno_labela.Text = "" + (0.15 * brutoIznos);
                porez_labela.Text = "" + (0.02 * (brutoIznos - 0.3 * brutoIznos));
                dohodak_labela.Text = "" + 0.022 * brutoIznos;
                neto_labela.Text = "" + (brutoIznos - Convert.ToDouble(mirovinsko_labela.Text) - Convert.ToDouble(zdravstveno_labela.Text) - Convert.ToDouble(porez_labela.Text) - Convert.ToDouble(dohodak_labela.Text));
            }
        }

        private void spremi_button_Click(object sender, EventArgs e)
        {

        }

        private void izlaz_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ObracunPlace_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
        }
    }
}
